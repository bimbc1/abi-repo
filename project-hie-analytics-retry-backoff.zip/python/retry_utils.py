import os
import time
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def retry_with_backoff(
    operation,
    max_attempts=None,
    retry_delay_seconds=None,
    return_bool=False,
):
    """
    Executes an operation with exponential backoff retry.
    """
    if max_attempts is None:
        max_attempts = int(os.environ.get("MAX_ATTEMPTS", 3))
    if retry_delay_seconds is None:
        retry_delay_seconds = int(os.environ.get("RETRY_DELAY_SECONDS", 2))

    if max_attempts <= 0:
        logger.info("Retry disabled (max_attempts=0)")
        try:
            result = operation()
            return True if return_bool else result
        except Exception as e:
            logger.error(f"Operation failed: {str(e)}")
            if return_bool:
                return False
            raise
            # ← fixed: raise on its own line instead of in ternary

    for attempt in range(1, max_attempts + 1):
        try:
            result = operation()
            if return_bool:
                return True
            return result
        except Exception as e:
            logger.warning(f"Attempt {attempt}/{max_attempts} failed: {str(e)}")
            if attempt == max_attempts:
                logger.error(f"All {max_attempts} attempts failed")
                if return_bool:
                    return False
                raise e
                # ← fixed: raise on its own line instead of in ternary
            wait_time = retry_delay_seconds * (2 ** (attempt - 1))
            logger.info(f"Waiting {wait_time}s before retry {attempt+1}")
            time.sleep(wait_time)